"""ComfyUI custom nodes that run mesh workflows in the installed Studio engine."""

from dataclasses import dataclass, replace
import json
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import tempfile
from uuid import uuid4

import folder_paths
import torch
from comfy.model_management import throw_exception_if_processing_interrupted
from comfy_api.latest import Types


MAX_BYTES=32*1024**2
FORMATS=('glb','obj','stl','ply','fbx','usda','usdz')


@dataclass(frozen=True)
class StudioMesh:
    data: bytes
    extension: str
    fit_mm: float = 0
    mm_per_unit: float = 1
    operations: tuple = ()
    lod: int = 0
    lod_keep: float = .5

    def append(self, operation):
        if self.lod:
            raise ValueError('Podłącz operacje geometrii przed węzłem LOD.')
        return replace(self,operations=self.operations+(operation,))


def studio_exe():
    explicit=os.environ.get('SKANER_STUDIO_EXE')
    path=Path(explicit) if explicit else Path.home()/'Desktop'/'Skaner Studio.exe'
    if not explicit and not path.is_file():
        found=shutil.which('Skaner Studio.exe')
        if found:
            path=Path(found)
    if not path.is_absolute() or not path.is_file() or path.suffix.lower()!='.exe':
        raise ValueError('Ustaw SKANER_STUDIO_EXE na pełną ścieżkę do Skaner Studio.exe b590 lub nowszego.')
    return path


def calculate(mesh,format):
    with tempfile.TemporaryDirectory(prefix='skaner-comfy-') as temporary:
        folder=Path(temporary)
        source=folder/f'input.{mesh.extension}'
        source.write_bytes(mesh.data)
        request=folder/'request.json'
        request.write_text(json.dumps({'source':source.name,'format':format,'fit_mm':mesh.fit_mm,
            'mm_per_unit':mesh.mm_per_unit,'operations':mesh.operations,'lod':mesh.lod,
            'lod_keep':mesh.lod_keep}),encoding='utf-8')
        env={**os.environ,'PYINSTALLER_RESET_ENVIRONMENT':'1'}
        with subprocess.Popen([str(studio_exe()),'--comfy-mesh-workflow',str(request)],cwd=folder,env=env,
                              stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
                              creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0)) as runner:
            try:
                for _ in range(240):
                    try:
                        runner.wait(timeout=1)
                        break
                    except subprocess.TimeoutExpired:
                        throw_exception_if_processing_interrupted()
                else:
                    raise ValueError('Przetwarzanie Studio przekroczyło 240 sekund.')
            finally:
                if runner.poll() is None:
                    runner.kill()
        result=folder/'result.json'
        if not result.is_file() or result.stat().st_size>128*1024:
            raise ValueError('Studio nie zwróciło wyniku. Sprawdź, czy uruchamiasz b590 lub nowsze.')
        report=json.loads(result.read_text(encoding='utf-8'))
        if runner.returncode or not report.get('ok'):
            raise ValueError(report.get('error','Przetwarzanie siatki nie powiodło się.'))
        output=[]
        for index,row in enumerate(report['files']):
            path=folder/f'output_{index}.{format}'
            if row['name']!=path.name or not 16<=path.stat().st_size<=MAX_BYTES:
                raise ValueError('Studio zwróciło nieprawidłowy plik wynikowy.')
            output.append((path.read_bytes(),row))
        if not output:
            raise ValueError('Studio nie zwróciło żadnej siatki.')
        return output


class LoadMesh:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required':{'file':('STRING',{'default':'model.glb'}),'fit_mm':('FLOAT',{'default':0.0,'min':0.0,'max':10000.0}),
                             'mm_per_unit':('FLOAT',{'default':1.0,'min':.001,'max':100000.0,'step':.001})}}
    RETURN_TYPES=('SKANER_MESH',)
    FUNCTION='load'
    CATEGORY='Skaner Studio'
    @classmethod
    def IS_CHANGED(cls, **_inputs):
        return float('nan')

    def load(self,file,fit_mm,mm_per_unit):
        root=Path(folder_paths.get_input_directory()).resolve()
        path=(root/file).resolve()
        extension=path.suffix[1:].lower()
        if not path.is_relative_to(root) or extension not in {'glb','obj','stl','fbx','usd','usda','usdc','usdz'}:
            raise ValueError('Wpisz ścieżkę do siatki w katalogu ComfyUI/input.')
        if not path.is_file() or not 16<=path.stat().st_size<=MAX_BYTES:
            raise ValueError('Brak siatki w ComfyUI/input lub przekroczono 32 MB.')
        return (StudioMesh(path.read_bytes(),extension,fit_mm,mm_per_unit),)


class FromMesh:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required':{'mesh':('MESH',),'fit_mm':('FLOAT',{'default':80.0,'min':0.0,'max':10000.0}),
                             'mm_per_unit':('FLOAT',{'default':1000.0,'min':.001,'max':100000.0})}}
    RETURN_TYPES=('SKANER_MESH',)
    FUNCTION='convert'
    CATEGORY='Skaner Studio'

    def convert(self,mesh,fit_mm,mm_per_unit):
        vertices,faces=mesh.vertices,mesh.faces
        if len(vertices.shape)!=3 or len(faces.shape)!=3 or vertices.shape[0]!=1 or faces.shape[0]!=1:
            raise ValueError('Wybierz jedną siatkę, bez wsadu wielu modeli.')
        if not 4<=vertices.shape[1]<=500000 or not 4<=faces.shape[1]<=500000 or vertices.shape[2]!=3 or faces.shape[2]!=3:
            raise ValueError('Węzeł przyjmuje do 500 000 wierzchołków i trójkątów.')
        points=vertices[0].detach().cpu().tolist()
        triangles=faces[0].detach().cpu().tolist()
        lines=[f'v {x:.9g} {-z:.9g} {y:.9g}' for x,y,z in points]
        lines.extend(f'f {a+1} {b+1} {c+1}' for a,b,c in triangles)
        data=('\n'.join(lines)+'\n').encode()
        if len(data)>MAX_BYTES:
            raise ValueError('Siatka przekracza 32 MB.')
        return (StudioMesh(data,'obj',fit_mm,mm_per_unit),)


class FromGlb:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required':{'file':('FILE_3D_GLB',),'fit_mm':('FLOAT',{'default':0.0,'min':0.0,'max':10000.0})}}
    RETURN_TYPES=('SKANER_MESH',)
    FUNCTION='convert'
    CATEGORY='Skaner Studio'
    def convert(self,file,fit_mm):
        data=file.get_bytes()
        if not 20<=len(data)<=MAX_BYTES or not data.startswith(b'glTF'):
            raise ValueError('Węzeł przyjmuje GLB do 32 MB.')
        return (StudioMesh(data,'glb',fit_mm),)


class Voxel:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required':{'mesh':('SKANER_MESH',),'voxel_mm':('FLOAT',{'default':1.0,'min':.05,'max':100.0,'step':.05})}}
    RETURN_TYPES=('SKANER_MESH',)
    FUNCTION='add'
    CATEGORY='Skaner Studio'
    def add(self,mesh,voxel_mm):
        return (mesh.append({'kind':'voxel','size':voxel_mm}),)


class Decimate:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required':{'mesh':('SKANER_MESH',),'keep':('FLOAT',{'default':.5,'min':.05,'max':1.0,'step':.05})}}
    RETURN_TYPES=('SKANER_MESH',)
    FUNCTION='add'
    CATEGORY='Skaner Studio'
    def add(self,mesh,keep):
        return (mesh.append({'kind':'decimate','keep':keep}),)


class Subdivide:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required':{'mesh':('SKANER_MESH',),'levels':('INT',{'default':1,'min':1,'max':3})}}
    RETURN_TYPES=('SKANER_MESH',)
    FUNCTION='add'
    CATEGORY='Skaner Studio'
    def add(self,mesh,levels):
        return (mesh.append({'kind':'subdivide','level':levels}),)


class Lod:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required':{'mesh':('SKANER_MESH',),'levels':('INT',{'default':3,'min':2,'max':5}),
                             'keep':('FLOAT',{'default':.5,'min':.05,'max':.95,'step':.05})}}
    RETURN_TYPES=('SKANER_MESH',)
    FUNCTION='add'
    CATEGORY='Skaner Studio'
    def add(self,mesh,levels,keep):
        return (replace(mesh,lod=levels,lod_keep=keep),)


class ToMesh:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required':{'mesh':('SKANER_MESH',)}}
    RETURN_TYPES=('MESH',)
    FUNCTION='convert'
    CATEGORY='Skaner Studio'
    def convert(self,mesh):
        if mesh.lod:
            raise ValueError('Zapisz cały łańcuch LOD węzłem Skaner Save Mesh.')
        data,_row=calculate(mesh,'mesh')[0]
        marker,points,triangles=struct.unpack_from('<4sII',data)
        if marker!=b'SKM1' or not points or not triangles or len(data)!=12+12*(points+triangles):
            raise ValueError('Studio zwróciło nieprawidłowy bufor siatki.')
        buffer=bytearray(data)
        vertices=torch.frombuffer(buffer,dtype=torch.float32,count=points*3,offset=12).reshape(1,points,3)
        faces=torch.frombuffer(buffer,dtype=torch.int32,count=triangles*3,offset=12+points*12).reshape(1,triangles,3).long()
        return (Types.MESH(vertices,faces),)


class SaveMesh:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required':{'mesh':('SKANER_MESH',),'format':(FORMATS,),
                             'name':('STRING',{'default':'Skaner'})}}
    RETURN_TYPES=('STRING',)
    FUNCTION='save'
    CATEGORY='Skaner Studio'
    OUTPUT_NODE=True
    @classmethod
    def IS_CHANGED(cls, **_inputs):
        return float('nan')

    def save(self,mesh,format,name):
        if format not in FORMATS or not re.fullmatch(r'[\w-]{1,80}',name):
            raise ValueError('Nazwa ma mieć do 80 liter, cyfr, podkreśleń lub myślników.')
        output=calculate(mesh,format)
        root=Path(folder_paths.get_output_directory())
        stamp=uuid4().hex[:10]
        saved=[]
        try:
            for i,(data,_row) in enumerate(output):
                tag=f'_LOD{i}' if len(output)>1 else ''
                path=root/f'{name}_{stamp}{tag}.{format}'
                with path.open('xb') as stream:
                    saved.append(path.name)
                    stream.write(data)
        except OSError:
            for file in saved:
                (root/file).unlink(missing_ok=True)
            raise
        listing=[{'filename':file,'subfolder':'','type':'output'} for file in saved]
        ui={'3d':listing} if format=='glb' else {'text':saved}
        return {'ui':ui,'result':('\n'.join(saved),)}


class OpenStudio(SaveMesh):
    @classmethod
    def INPUT_TYPES(cls):
        return {'required':{'mesh':('SKANER_MESH',),'name':('STRING',{'default':'Skaner'})}}
    FUNCTION='open'
    def open(self,mesh,name):
        if mesh.lod:
            raise ValueError('Otwórz jedną siatkę, a łańcuch LOD zapisz osobnym węzłem.')
        saved=self.save(mesh,'glb',name)
        path=Path(folder_paths.get_output_directory())/saved['result'][0]
        subprocess.Popen([str(studio_exe()),'--comfy-open-model',str(path)],
                         env={**os.environ,'PYINSTALLER_RESET_ENVIRONMENT':'1'},
                         stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        return saved


NODE_CLASS_MAPPINGS={
    'SkanerLoadMesh':LoadMesh,'SkanerFromMesh':FromMesh,'SkanerVoxelRemesh':Voxel,
    'SkanerDecimate':Decimate,'SkanerSubdivide':Subdivide,'SkanerLodChain':Lod,
    'SkanerSaveMesh':SaveMesh,'SkanerToMesh':ToMesh,'SkanerFromGLB':FromGlb,'SkanerOpenStudio':OpenStudio,
}
NODE_DISPLAY_NAME_MAPPINGS={
    'SkanerLoadMesh':'Skaner Load Mesh','SkanerFromMesh':'Skaner from MESH','SkanerVoxelRemesh':'Skaner Voxel Remesh',
    'SkanerDecimate':'Skaner Decimate','SkanerSubdivide':'Skaner Subdivide','SkanerLodChain':'Skaner LOD Chain',
    'SkanerSaveMesh':'Skaner Save Mesh','SkanerToMesh':'Skaner to MESH',
    'SkanerFromGLB':'Skaner from GLB','SkanerOpenStudio':'Skaner Open in Studio',
}
