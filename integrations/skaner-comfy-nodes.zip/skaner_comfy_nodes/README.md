# Węzły Skaner Studio dla ComfyUI

Rozpakuj folder `skaner_comfy_nodes` do `ComfyUI/custom_nodes` i uruchom ponownie ComfyUI. Węzły pojawią się w kategorii **Skaner Studio**. Wymagają desktopowego Studio b590 lub nowszego. Domyślnie używają pliku `Skaner Studio.exe` na pulpicie. Jeżeli EXE jest w innym miejscu, ustaw zmienną środowiskową `SKANER_STUDIO_EXE` przed uruchomieniem ComfyUI.

1. Podłącz **Skaner from MESH**, **Skaner from GLB** lub **Skaner Load Mesh**. Pliki dla Load Mesh umieść w `ComfyUI/input`.
2. Dodaj **Skaner Voxel Remesh**, **Skaner Subdivide** lub **Skaner Decimate**. Voxel podaje się w mm. Remesh wymaga zamkniętej bryły. Wartość `keep` w Decimate oznacza żądaną część trójkątów.
3. Opcjonalnie dodaj **Skaner LOD Chain** bezpośrednio przed zapisem.
4. **Skaner Save Mesh** przelicza łańcuch i zapisuje pliki do `ComfyUI/output`. **Skaner to MESH** przekazuje pojedynczą siatkę z powrotem do węzłów ComfyUI. **Skaner Open in Studio** zapisuje GLB i otwiera go w nowym oknie Studio.

GLB stosuje metry i oś Y w górę. OBJ, STL i PLY ze Studio stosują mm i oś Z w górę. Parametr `fit_mm` dopasowuje najdłuższy wymiar. Dla OBJ/STL parametr `mm_per_unit` pozwala przeliczyć jednostki źródła. FBX i USD wymagają lokalnego Blendera 5.2+. Obróbka dotyczy geometrii. W tym łańcuchu mapy, malowanie i warstwy rzeźby nie przechodzą między plikami.
