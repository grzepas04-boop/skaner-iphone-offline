"""Translate Studio sculpt annotations to Blender's actual mesh attributes."""

import json
import re
import struct
from contextlib import contextmanager

import numpy as np
import bmesh

MASK = "_SKANER_MASK"
FACE_SET = "_SKANER_FACE_SET"
POLYGON = "_SKANER_POLYGON"
GROUPS = "skaner_group_names"
NATIVE_MASK = ".sculpt_mask"
NATIVE_SET = ".sculpt_face_set"


def group_table(raw):
    if not isinstance(raw, str) or len(raw) > 4 * 1024 * 1024:
        raise ValueError("Brak poprawnego słownika grup ścian.")
    table = json.loads(raw)
    groups, sets = table["groups"], table["sets"]
    if (not isinstance(groups, list) or len(groups) > 256
            or any(not isinstance(g, dict) or not re.fullmatch(r"faces-[a-zA-Z0-9-]{1,80}", g.get("id", ""))
                   or not isinstance(g.get("name"), str) or not g["name"].strip() or len(g["name"]) > 120 for g in groups)
            or len({g["id"] for g in groups}) != len(groups)
            or not isinstance(sets, list) or not 1 <= len(sets) <= 150001 or sets[0] != []
            or any(not isinstance(ids, list) or len(ids) > len(groups)
                   or any(type(i) is not int or not 0 <= i < len(groups) for i in ids)
                   or len(set(ids)) != len(ids) for ids in sets)):
        raise ValueError("Nieprawidłowy słownik grup ścian.")
    return groups, sets


@contextmanager
def export_attributes(objects):
    added = []
    extras = []
    metadata = {}
    try:
        for obj in objects:
            mesh = obj.data
            if mesh not in metadata:
                metadata[mesh] = None
                mask = mesh.attributes.get(NATIVE_MASK)
                if mask is not None:
                    if mesh.attributes.get(MASK) or mask.domain != "POINT" or mask.data_type != "FLOAT":
                        raise ValueError("Nieprawidłowy atrybut maski Blendera.")
                    values = np.empty(len(mesh.vertices), dtype=np.float32)
                    mask.data.foreach_get("value", values)
                    if not np.isfinite(values).all() or np.any((values < 0) | (values > 1)):
                        raise ValueError("Maska Blendera musi zawierać wartości 0–1.")
                    attribute = mesh.attributes.new(MASK, "FLOAT", "POINT")
                    added.append((mesh, MASK))
                    attribute.data.foreach_set("value", values)
                face_sets = mesh.attributes.get(NATIVE_SET)
                if face_sets is not None:
                    if mesh.attributes.get(FACE_SET) or face_sets.domain != "FACE" or face_sets.data_type != "INT":
                        raise ValueError("Nieprawidłowy atrybut grup ścian Blendera.")
                    values = np.empty(len(mesh.polygons), dtype=np.int32)
                    face_sets.data.foreach_get("value", values)
                    groups, sets = group_table(mesh[GROUPS]) if GROUPS in mesh else ([], [[]])
                    native = {i + 1: i for i in range(len(sets))} if GROUPS in mesh else {}
                    group_ids = {g["id"] for g in groups}
                    for label in np.unique(values):
                        label = int(label)
                        if label <= 0 or label in native:
                            continue
                        native[label] = len(sets)
                        sets.append([len(groups)])
                        group_id = f"faces-blender-{label}"
                        while group_id in group_ids:
                            group_id += "-new"
                        group_ids.add(group_id)
                        groups.append({"id": group_id, "name": f"Face Set {label}"})
                    serialized = json.dumps({"groups": groups, "sets": sets}, ensure_ascii=False)
                    group_table(serialized)
                    metadata[mesh] = serialized
                    # FACE custom attributes are expanded to glTF corner vertices.
                    attribute = mesh.attributes.new(FACE_SET, "FLOAT", "FACE")
                    added.append((mesh, FACE_SET))
                    attribute.data.foreach_set("value", np.array([native.get(int(n), 0) for n in values], dtype=np.float32))
                if any(poly.loop_total == 4 for poly in mesh.polygons):
                    if mesh.attributes.get(POLYGON):
                        raise ValueError("Siatka ma już atrybut zarezerwowany przez most.")
                    attribute = mesh.attributes.new(POLYGON, "FLOAT", "FACE")
                    added.append((mesh, POLYGON))
                    attribute.data.foreach_set("value", np.array([poly.index+1 if poly.loop_total==4 else 0
                                                                  for poly in mesh.polygons], dtype=np.float32))
            if metadata[mesh] is not None:
                extras.append((obj, obj.get(GROUPS)))
                obj[GROUPS] = metadata[mesh]
        yield
    finally:
        for obj, old in extras:
            if old is None:
                del obj[GROUPS]
            else:
                obj[GROUPS] = old
        for mesh, name in reversed(added):
            mesh.attributes.remove(mesh.attributes[name])


def _accessor(document, binary, index, width, components):
    accessor = document["accessors"][index]
    component = accessor["componentType"]
    dtypes = {5121: "u1", 5123: "<u2", 5125: "<u4", 5126: "<f4"}
    if (component not in components or accessor.get("sparse") or accessor.get("normalized")
            or accessor["type"] != ("SCALAR" if width == 1 else "VEC3")
            or not 0 < accessor["count"] <= 450000):
        raise ValueError("Nieobsługiwany format atrybutu rzeźby GLB.")
    view = document["bufferViews"][accessor["bufferView"]]
    dtype = np.dtype(dtypes[component])
    stride = view.get("byteStride", width * dtype.itemsize)
    offset = accessor.get("byteOffset", 0)
    base = view.get("byteOffset", 0)
    count = accessor["count"]
    if (view["buffer"] != 0 or min(base, offset) < 0 or stride < width * dtype.itemsize
            or offset + (count - 1) * stride + width * dtype.itemsize > view["byteLength"]
            or base + view["byteLength"] > len(binary)):
        raise ValueError("Atrybut rzeźby wykracza poza bufor GLB.")
    return np.ndarray((count, width), dtype=dtype, buffer=binary, offset=base + offset,
                      strides=(stride, dtype.itemsize))


def decode_sculpt(document, chunk):
    transfers = {}
    if len(chunk) < 8 or struct.unpack_from("<I4s", chunk) != (len(chunk) - 8, b"BIN\0"):
        raise ValueError("Brak poprawnej sekcji BIN pliku wymiany.")
    binary = memoryview(chunk)[8:]
    for node in document.get("nodes", []):
        extras = node.get("extras", {})
        key = extras.get("skaner_bridge_id")
        if "mesh" not in node or not key:
            continue
        primitives = document["meshes"][node["mesh"]]["primitives"]
        annotated = [p for p in primitives if any(k in p["attributes"] for k in (MASK, FACE_SET, POLYGON))]
        if not annotated:
            continue
        if len(primitives) != 1 or key in transfers:
            raise ValueError("Atrybuty rzeźby wymagają jednej siatki na część.")
        primitive = annotated[0]
        if primitive.get("mode", 4) != 4:
            raise ValueError("Atrybuty rzeźby wymagają trójkątów.")
        attrs = primitive["attributes"]
        positions = _accessor(document, binary, attrs["POSITION"], 3, (5126,))
        indices = (_accessor(document, binary, primitive["indices"], 1, (5121, 5123, 5125))[:, 0]
                   if "indices" in primitive else np.arange(len(positions)))
        if len(indices) % 3 or np.any(indices >= len(positions)) or not np.isfinite(positions).all():
            raise ValueError("Nieprawidłowe trójkąty atrybutów rzeźby.")
        mask = None
        if MASK in attrs:
            values = _accessor(document, binary, attrs[MASK], 1, (5126,))[:, 0]
            if len(values) != len(positions) or not np.isfinite(values).all() or np.any((values < 0) | (values > 1)):
                raise ValueError("Nieprawidłowa maska GLB.")
            mask = values[indices]
        labels, table = None, None
        if FACE_SET in attrs:
            table = extras.get(GROUPS)
            _, sets = group_table(table)
            values = _accessor(document, binary, attrs[FACE_SET], 1, (5126,))[:, 0]
            if (len(values) != len(positions) or not np.isfinite(values).all()
                    or np.any(values != np.floor(values)) or np.any((values < 0) | (values >= len(sets)))):
                raise ValueError("Nieprawidłowe wartości grup ścian GLB.")
            corners = values[indices].reshape((-1, 3))
            if np.any(corners != corners[:, :1]):
                raise ValueError("Narożniki trójkąta mają sprzeczne grupy ścian.")
            labels = corners[:, 0].astype(np.int32)
        quads = None
        if POLYGON in attrs:
            values = _accessor(document, binary, attrs[POLYGON], 1, (5126,))[:, 0]
            if (len(values) != len(positions) or not np.isfinite(values).all()
                    or np.any(values != np.floor(values)) or np.any((values < 0) | (values > len(indices)//3))):
                raise ValueError("Nieprawidłowe etykiety czworokątów GLB.")
            corners = values[indices].reshape((-1, 3))
            if np.any(corners != corners[:, :1]):
                raise ValueError("Narożniki trójkąta mają sprzeczne etykiety wielokątów.")
            quads = corners[:, 0].astype(np.int32)
        transfers[key] = (positions[indices], mask, labels, table, quads)
    return transfers


def apply_sculpt(mesh, transfer, unit):
    source, weights, labels, table, quads = transfer
    if len(mesh.loops) != len(source) or len(mesh.polygons) * 3 != len(source):
        raise ValueError("Blender zmienił liczbę trójkątów podczas wczytywania atrybutów.")
    indices = np.empty(len(mesh.loops), dtype=np.int32)
    points = np.empty(len(mesh.vertices) * 3, dtype=np.float32)
    mesh.loops.foreach_get("vertex_index", indices)
    mesh.vertices.foreach_get("co", points)
    expected = source[:, [0, 2, 1]].copy()
    expected[:, 1] *= -1
    if not np.allclose(points.reshape((-1, 3))[indices] * unit, expected, rtol=2e-6, atol=1e-6):
        raise ValueError("Nie potwierdzono kolejności narożników po otwarciu GLB.")
    for name in (MASK, FACE_SET, POLYGON):
        attribute = mesh.attributes.get(name)
        if attribute is not None:
            mesh.attributes.remove(attribute)
    if weights is not None:
        minima = np.full(len(mesh.vertices), np.inf, dtype=np.float32)
        maxima = np.full(len(mesh.vertices), -np.inf, dtype=np.float32)
        np.minimum.at(minima, indices, weights)
        np.maximum.at(maxima, indices, weights)
        if not np.array_equal(minima, maxima):
            raise ValueError("Połączone wierzchołki mają sprzeczne wartości maski.")
        mesh.attributes.new(NATIVE_MASK, "FLOAT", "POINT").data.foreach_set("value", maxima)
    if labels is not None:
        mesh.attributes.new(NATIVE_SET, "INT", "FACE").data.foreach_set("value", labels + 1)
        mesh[GROUPS] = table
    if quads is not None and np.any(quads):
        dissolve_quad_diagonals(mesh, quads, labels, points)


def dissolve_quad_diagonals(mesh, quads, labels, points):
    """Remove only diagonals explicitly tagged by the source polygon."""
    members = {}
    for face, label in enumerate(quads):
        if label:
            members.setdefault(int(label), []).append(face)
    if any(len(faces) != 2 for faces in members.values()):
        raise ValueError("Każdy czworokąt w pliku wymiany musi mieć dwa trójkąty.")
    expected = {tuple(sorted(poly.vertices)): int(labels[poly.index])+1 if labels is not None else None
                for poly in mesh.polygons if not quads[poly.index]}
    warped = {}
    coordinates = points.reshape((-1, 3)).astype(np.float64)
    uv_layers = list(mesh.uv_layers)
    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        bm.verts.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        edges = []
        for first, second in members.values():
            faces = [mesh.polygons[i] for i in (first, second)]
            a, b = (set(poly.vertices) for poly in faces)
            common = sorted(a & b)
            if len(common) != 2 or len(a | b) != 4 or labels is not None and labels[first] != labels[second]:
                raise ValueError("Czworokąt ma niespójną geometrię lub grupę na przekątnej.")
            for layer in uv_layers:
                left, right = ({mesh.loops[i].vertex_index: tuple(layer.data[i].uv) for i in poly.loop_indices}
                               for poly in faces)
                if any(left[vertex] != right[vertex] for vertex in common):
                    raise ValueError("Nie można połączyć czworokąta przez szew UV.")
            edge = bm.edges.get(tuple(bm.verts[i] for i in common))
            if edge is None or {face.index for face in edge.link_faces} != {first, second}:
                raise ValueError("Nie potwierdzono przekątnej czworokąta.")
            edges.append(edge)
            boundary = tuple(sorted(a | b))
            expected[boundary] = int(labels[first])+1 if labels is not None else None
            offsets = coordinates[list(boundary)[1:]] - coordinates[boundary[0]]
            scale = np.linalg.norm(offsets, axis=1).max()
            if abs(np.linalg.det(offsets)) > 1e-7 * scale**3:
                warped[boundary] = {tuple(sorted(a)), tuple(sorted(b))}
        if len(expected) != len(mesh.polygons)-len(edges):
            raise ValueError("W pliku są powielone wielokąty.")
        bmesh.ops.dissolve_edges(bm, edges=edges, use_verts=False)
        bm.to_mesh(mesh)
    finally:
        bm.free()
    after = np.empty(len(mesh.vertices)*3, dtype=np.float32)
    mesh.vertices.foreach_get("co", after)
    attr = mesh.attributes.get(NATIVE_SET)
    actual = {tuple(sorted(poly.vertices)): attr.data[poly.index].value if attr is not None else None for poly in mesh.polygons}
    if len(actual) != len(mesh.polygons) or actual != expected or not np.array_equal(after, points):
        raise ValueError("Blender zmienił wierzchołki, grupy lub granice podczas odtwarzania czworokątów.")
    if warped:
        mesh.calc_loop_triangles()
        boundaries = {poly.index: tuple(sorted(poly.vertices)) for poly in mesh.polygons if poly.loop_total==4}
        rendered = {boundary: set() for boundary in warped}
        for tri in mesh.loop_triangles:
            boundary = boundaries.get(tri.polygon_index)
            if boundary in rendered:
                rendered[boundary].add(tuple(sorted(tri.vertices)))
        if rendered != warped:
            raise ValueError("Blender wybrał inną przekątną nierównego czworokąta. Popraw ścianę w źródle lub użyj trójkątów.")
