"""Skaner Studio's local mesh exchange for Blender."""

bl_info = {
    "name": "Skaner Studio Bridge",
    "author": "Skaner Studio",
    "version": (1, 2, 0),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > Skaner Studio",
    "category": "Import-Export",
}

import json
from pathlib import Path
import re
import struct
import tempfile
from urllib.error import HTTPError
from urllib.request import HTTPRedirectHandler, ProxyHandler, Request, build_opener
import uuid

import bpy
from .sculpt_data import GROUPS, apply_sculpt, decode_sculpt, export_attributes

KEY = "skaner_bridge_id"
KEY_PATTERN = re.compile(r"blender:[a-f0-9]{32}|studio:part-[a-z0-9-]{1,72}")
MAX_BYTES = 32 * 1024 * 1024


class LocalOnly(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def request(code, method, direction, data=None, identifier=None):
    match = re.fullmatch(r"(http://127\.0\.0\.1:([0-9]{1,5}))#([a-zA-Z0-9_-]{32})", code.strip())
    if not match or not 1 <= int(match[2]) <= 65535:
        raise ValueError("Wklej aktualny kod z Projekt → Most Blender w Skaner Studio.")
    headers = {"X-Skaner-Bridge": match[3], "X-Skaner-Sculpt": "2"}
    if data is not None:
        headers["Content-Type"] = "model/gltf-binary"
    if identifier is not None:
        headers["X-Skaner-Transfer"] = identifier
    url = match[1] + "/api/blender-bridge/" + direction
    try:
        with build_opener(ProxyHandler({}), LocalOnly()).open(Request(url, data, headers, method=method), timeout=20) as response:
            payload = response.read(MAX_BYTES + 1)
            if len(payload) > MAX_BYTES:
                raise ValueError("Model przekracza limit 32 MB.")
            return payload, response.headers.get("X-Skaner-Transfer")
    except HTTPError as error:
        try:
            message = json.loads(error.read(4096))["error"]
        except (ValueError, KeyError):
            message = f"Błąd połączenia ({error.code})."
        raise ValueError(message) from error


def mesh_key(obj):
    value = obj.get(KEY)
    return value if isinstance(value, str) and KEY_PATTERN.fullmatch(value) else None


def glb_json(data):
    if len(data) < 20 or len(data) > MAX_BYTES or struct.unpack_from("<4sII", data) != (b"glTF", 2, len(data)):
        raise ValueError("Nieprawidłowy plik GLB lub przekroczone 32 MB.")
    size, kind = struct.unpack_from("<I4s", data, 12)
    if kind != b"JSON" or size % 4 or 20 + size > len(data):
        raise ValueError("Nieprawidłowy nagłówek GLB.")
    payload = json.loads(data[20:20 + size])
    for section in ("images", "buffers"):
        for resource in payload.get(section, []):
            if "uri" in resource and not resource["uri"].startswith("data:"):
                raise ValueError("Most wymaga zasobów osadzonych w GLB.")
    return payload, data[20 + size:]


def prepare_exchange_glb(data, unit):
    payload, binary = glb_json(data)
    for node in payload.get("nodes", []):
        extras = node.pop("extras", {})
        key = extras.get(KEY)
        if key:
            node["extras"] = {KEY: key}
            if GROUPS in extras:
                node["extras"][GROUPS] = extras[GROUPS]
    # Blender's glTF reader applies scale_length but its writer exports Blender
    # units directly. Author the physical conversion on each scene root.
    if unit != 1:
        for scene in payload["scenes"]:
            roots = scene.get("nodes", [])
            scene["nodes"] = [len(payload["nodes"])]
            payload["nodes"].append({"name": "Jednostki sceny", "scale": [unit] * 3, "children": roots})
    metadata = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode()
    metadata += b" " * (-len(metadata) % 4)
    return struct.pack("<4sIII4s", b"glTF", 2, 20 + len(metadata) + len(binary), len(metadata), b"JSON") + metadata + binary


def send(context, code):
    selected = list(context.selected_objects)
    if context.mode != "OBJECT" or not selected or any(obj.type != "MESH" for obj in selected):
        raise ValueError("W trybie obiektowym zaznacz jedną lub kilka siatek.")
    used_keys = {}
    for obj in context.scene.objects:
        if obj.type == "MESH" and mesh_key(obj):
            used_keys.setdefault(mesh_key(obj), []).append(obj)
    assignments = []
    try:
        for obj in selected:
            if len(obj.material_slots) > 1 or any(modifier.type == "ARMATURE" for modifier in obj.modifiers):
                raise ValueError(f"{obj.name}: wybierz siatkę z maksymalnie jednym materiałem, bez szkieletu.")
            old = obj.get(KEY)
            if not mesh_key(obj) or len(used_keys.get(mesh_key(obj), [])) > 1:
                assignments.append((obj, old))
                obj[KEY] = "blender:" + uuid.uuid4().hex
        with export_attributes(selected), tempfile.TemporaryDirectory(prefix="skaner-bridge-") as temp:
            path = Path(temp) / "model.glb"
            result = bpy.ops.export_scene.gltf(filepath=str(path), export_format="GLB", use_selection=True,
                                               export_extras=True, export_apply=False, export_skins=False,
                                               export_animations=False, export_morph=True, export_yup=True, export_attributes=True)
            if result != {"FINISHED"} or path.stat().st_size > MAX_BYTES:
                raise ValueError("Eksport nie powiódł się lub przekracza 32 MB.")
            data = prepare_exchange_glb(path.read_bytes(), context.scene.unit_settings.scale_length)
        request(code, "PUT", "to-studio", data)
    except Exception:
        for obj, old in assignments:
            if old is None:
                del obj[KEY]
            else:
                obj[KEY] = old
        raise
    return len(selected)


def receive(context, code, keep_materials):
    if context.mode != "OBJECT":
        raise ValueError("Przed odbiorem przełącz Blender na tryb obiektowy.")
    payload, identifier = request(code, "GET", "to-blender")
    document, binary = glb_json(payload)
    annotations = decode_sculpt(document, binary)
    if not identifier:
        raise ValueError("Brak identyfikatora przesyłki.")
    prior_objects = set(bpy.data.objects)
    existing = {}
    for obj in context.scene.objects:
        if obj.type == "MESH" and mesh_key(obj):
            existing.setdefault(mesh_key(obj), []).append(obj)
    active = context.view_layer.objects.active
    selected = list(context.selected_objects)
    incoming = []
    new_parts = []
    replacements = []
    try:
        with tempfile.TemporaryDirectory(prefix="skaner-bridge-") as temp:
            path = Path(temp) / "model.glb"
            path.write_bytes(payload)
            if bpy.ops.import_scene.gltf(filepath=str(path), merge_vertices=True) != {"FINISHED"}:
                raise ValueError("Nie udało się otworzyć GLB ze Studio.")
        incoming = [obj for obj in context.scene.objects if obj not in prior_objects and obj.type == "MESH"]
        keys = [mesh_key(obj) for obj in incoming]
        if not keys or None in keys or len(set(keys)) != len(keys):
            raise ValueError("Brak unikatowych identyfikatorów części w odebranym GLB.")
        context.view_layer.update()
        for source, key in zip(incoming, keys):
            if key in annotations:
                apply_sculpt(source.data, annotations[key], context.scene.unit_settings.scale_length)
                if GROUPS in source:
                    del source[GROUPS]
            targets = existing.get(key, [])
            if len(targets) > 1:
                raise ValueError(f"{source.name}: kilka obiektów Blendera ma ten sam identyfikator.")
            if not targets:
                new_parts.append((source, source.matrix_world.copy()))
                continue
            target = targets[0]
            old_keys = target.data.shape_keys
            if target.library or target.data.library or old_keys and old_keys.animation_data:
                raise ValueError(f"{target.name}: siatka jest powiązana z biblioteką lub ma animowane klucze kształtu.")
            if abs(target.matrix_world.determinant()) < 1e-12:
                raise ValueError(f"{target.name}: popraw zerową skalę przed odbiorem.")
            mesh = source.data
            if mesh.users > 1:
                mesh = mesh.copy()
            mesh.transform(target.matrix_world.inverted() @ source.matrix_world, shape_keys=True)
            if keep_materials:
                materials = [slot.material for slot in target.material_slots]
                mesh.materials.clear()
                for material in materials:
                    mesh.materials.append(material)
            replacements.append((target, mesh))
        for source, matrix in new_parts:
            source.parent = None
            source.matrix_world = matrix
        for target, mesh in replacements:
            target.data = mesh
    except Exception:
        new_parts.clear()
        raise
    finally:
        keep = {source for source, _ in new_parts}
        for obj in set(bpy.data.objects) - prior_objects - keep:
            bpy.data.objects.remove(obj, do_unlink=True)
        if not new_parts:
            for obj in selected:
                obj.select_set(True)
            context.view_layer.objects.active = active
    warning = ""
    try:
        request(code, "DELETE", "to-blender", identifier=identifier)
    except Exception:
        warning = " Zmiany zastosowano, ale most nie potwierdził odbioru."
    return len(replacements), len(new_parts), warning


class SKANER_OT_send(bpy.types.Operator):
    bl_idname = "skaner_bridge.send"
    bl_label = "Wyślij do Studio"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        try:
            count = send(context, context.window_manager.skaner_bridge_code)
        except Exception as error:
            self.report({"ERROR"}, str(error))
            return {"CANCELLED"}
        self.report({"INFO"}, f"Wysłano {count}. W Studio kliknij Odbierz z Blendera.")
        return {"FINISHED"}


class SKANER_OT_receive(bpy.types.Operator):
    bl_idname = "skaner_bridge.receive"
    bl_label = "Odbierz ze Studio"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        try:
            updated, added, warning = receive(context, context.window_manager.skaner_bridge_code,
                                             context.window_manager.skaner_bridge_materials)
        except Exception as error:
            self.report({"ERROR"}, str(error))
            return {"CANCELLED"}
        self.report({"WARNING"} if warning else {"INFO"}, f"Zaktualizowano {updated}, dodano {added}.{warning}")
        return {"FINISHED"}


class SKANER_PT_bridge(bpy.types.Panel):
    bl_label = "Most Skaner Studio"
    bl_idname = "SKANER_PT_bridge"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Skaner Studio"

    def draw(self, context):
        wm = context.window_manager
        self.layout.prop(wm, "skaner_bridge_code", text="Kod")
        self.layout.prop(wm, "skaner_bridge_materials")
        self.layout.operator(SKANER_OT_send.bl_idname)
        self.layout.operator(SKANER_OT_receive.bl_idname)


CLASSES = (SKANER_OT_send, SKANER_OT_receive, SKANER_PT_bridge)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.WindowManager.skaner_bridge_code = bpy.props.StringProperty(name="Kod połączenia", subtype="PASSWORD", options={"SKIP_SAVE"})
    bpy.types.WindowManager.skaner_bridge_materials = bpy.props.BoolProperty(name="Zachowaj materiały Blendera", default=False)


def unregister():
    del bpy.types.WindowManager.skaner_bridge_materials
    del bpy.types.WindowManager.skaner_bridge_code
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
